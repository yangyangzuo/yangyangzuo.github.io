<template>
      <el-container height="100%">
        <el-aside width="50%">
          <div ref="container" class="robotDom" :style="{ backgroundColor: bgColor}">
            <!-- 动态添加的节点将会被插入到这里 -->
        </div>
        </el-aside>
        <el-main style="height: 900px;width:400px;position:absolute;right:0;top:0;">
          <el-space wrap direction="vertical">
            <!-- <div>
              宽<el-input v-model="digWidth" style="width: 240px" placeholder="Please input" />
            </div>
            <div>
              高<el-input v-model="digHeight" style="width: 240px" placeholder="Please input" />
            </div> -->
            <div>
              x偏移<el-input v-model="x" style="width: 240px" placeholder="Please input" />
            </div>
            <div>
              y偏移<el-input v-model="y" style="width: 240px" placeholder="Please input" />
            </div>
            <div>
              背景色     <el-color-picker v-model="bgColor" size="large" />
            </div>
            <div>
              文本<el-input
                v-model="content"
                style="width: 240px"
                :autosize="{ minRows: 2, maxRows: 4 }"
                type="textarea"
                placeholder="Please input"
            />
            </div>
            <div class="btnArea">
              <el-button @click="play">播放</el-button>
              <el-button @click="stop">停止播放</el-button>
            </div>
          </el-space>
        </el-main>
      </el-container>
</template>

<script lang="ts" setup>
import { ref, onMounted ,watch} from 'vue';
import * as CryptoJS from "crypto-js";


const digWidth = ref(384)
const digHeight = ref(610)
const content = ref('')
const bgColor = ref('#f5f5f5')
const x = ref(280)
const y = ref(200)


const props = defineProps({
isUse: Boolean,
})
declare global {
  interface Window {
      DigitalRender: any;
  }
}


const { Robot } = window.DigitalRender;

const playing = ref(false);

const container:any = ref(null);
let render:any
const initRobot = ()=>{
 // 获取当前robotDom的宽度
 render = new Robot({
      envSettings: {
          cameraType: 1,
          character: 'Dazhen',
          width: digWidth.value,
          height: digHeight.value,
          x: x.value,
          y: y.value,
      }
  });
  container.value.appendChild(render.container);
  let isMove: boolean;
  let mouseX: number;
  let mouseY: number;


  render.container.addEventListener('mousemove', (event: { x: any; y: any; toElement: { offsetTop: any; offsetLeft: any; }; }) => {
      if (!isMove) return;
      const { x, y } = event;
      render.setPosition(x - mouseX - window.innerWidth / 6, y - mouseY - window.innerHeight / 6);
  })

  render.container.addEventListener('mousedown', (event: { x: any; y: any; toElement: { offsetTop: any; offsetLeft: any; }; }) => {
      const { x, y, toElement: { offsetTop, offsetLeft } } = event;
      mouseX = x - offsetLeft - window.innerWidth / 6;
      mouseY = y - offsetTop - window.innerHeight / 6;
      isMove = true
  })

  render.container.addEventListener('mouseup', () => {
      isMove = false
      mouseX = 0
      mouseY = 0
  })
}
onMounted(() => {
  initRobot()
});
watch(() =>[x.value,y.value,], (val) => {
  render.setPosition(x.value, y.value);
})
const requestQueue: any[] = [];
let isProcessing = false;
let msgArr: any[] = [];
const stopStatus = ref(false)
const currentMsgQueue:any = ref([]) //缓存当前播放的音频队列
const play = (data:any) => {
  audioAjax(content.value);
}

// 清空队列并停止
const stop = () => {
  render.stopVoice();
  render.clearVoiceList()
}

async function audioAjax(data:any) {
  const { audioUrl, bs, shape } = await sendTTS(data);
    render.sendAudioInfo({
        audioUrl: audioUrl,
        bs: {
            bs: bs,
            shape: shape
        }
    })
}

class Http {
  xhr: XMLHttpRequest;
  constructor() {
      this.xhr = new XMLHttpRequest();
  }
  openApi(
      method: string,
      url: any,
      data: { appSign: any; traceId?: any; timestamp?: number; text?: string; voice?: any; speechRate?: any; format?: string; volume?: number;
   }): Promise<any> {
      return new Promise((resolve, reject) => {
          this.xhr.onreadystatechange = () => {
              // 通信成功时，状态值为4
              if (this.xhr.readyState === 4) {
                  if (this.xhr.status === 200) {
                      let param = JSON.parse(this.xhr.responseText)
                      // console.log(`======== 返回${url}========`, param)
                      resolve(param)
                      param = null;
                      // console.log(this.xhr.responseText);
                  } else {
                      reject(this.xhr.statusText)
                      // console.error(this.xhr.statusText);
                  }
              }
          }

          this.xhr.open(method, `${url}`);
          this.xhr.setRequestHeader("Content-Type", "application/json;UTF-8");
          this.xhr.setRequestHeader("App-Sign", data.appSign);
          this.xhr.setRequestHeader("Accept", "*/*");
          this.xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
          this.xhr.setRequestHeader("Access-Control-Allow-Headers", "Content-Type");
          this.xhr.setRequestHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
          delete data.appSign;

          // console.log(`======== 请求${url}========`, data)
          this.xhr.send(JSON.stringify(data));
      })
  }
  cancelRequest() {
      this.xhr.abort();
  }
}

async function sendTTS(text: string) {
  const ajaxObj = new Http();
  let apiKey: string = '0DA72D11D2B246949CAF99B25D3521FD';
  let secretKey: string = '57CE5FA3114B459D9CD07C7A5188FB0F';
  // 需要替换url中=后面的apiKey及apiKey与secretKey两个参数的值
  const serveInfo = {
      tts: {
          url: `/csrobot/cschannels/openapi/video/texttovoicethenbs?apiKey=${apiKey}`,
          apiKey: apiKey,
          secretKey: secretKey
      }
  }
  const traceId = Robot.uuidv4();
  const timestamp = parseInt((new Date().getTime() / 1000).toString());
  const sha256 = CryptoJS.SHA256(
      `${serveInfo.tts.apiKey}-${serveInfo.tts.secretKey}-${traceId}-${timestamp}`
  );
  const appSign = sha256.toString();
  // let bs: any, shape: any, audioUrl: any;
  let { data:{ bs, shape, audioUrl} }: any = await ajaxObj.openApi("POST", serveInfo.tts.url, {
      appSign: appSign,
      traceId: traceId,
      timestamp: timestamp,
      text: text,
      voice: 'yixiaoling',
      speechRate: 1,
      format: 'WAV',
      volume: 100
  });
  // console.info('接口返回对应话术：', text);
  // console.log('audioUrl', audioUrl)
  return {
      audioUrl: audioUrl,
      shape: shape,
      bs: bs,
      content: text,
      timestamp: timestamp
  };
}
</script>

<style  >
.btnArea{
  text-align: center;
}
.robotDom{
  height: 100%;
}

</style>