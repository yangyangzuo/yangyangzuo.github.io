import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    vue(),
  ],
  server: {
    host: true,
    open: true,
    port: 3000,
    proxy: {
     '/csrobot/cschannels/openapi/video/texttovoicethenbs': {
        target: 'https://150.223.245.42/csrobot/cschannels/openapi/video/texttovoicethenbs',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/csrobot\/cschannels\/openapi\/video\/texttovoicethenbs/, '') // 重写路径
      },
 
    }
  },
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    },
  },
})
